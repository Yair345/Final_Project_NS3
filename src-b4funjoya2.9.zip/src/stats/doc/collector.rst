.. include:: replace.txt

.. heading hierarchy:
   ************* Section (#.#)
   ============= Subsection (#.#.#)
   ############# Paragraph (no number)
   ~~~~~~~~~~~~~ Sub-paragraph (no number)

Collectors
**********

This section is a placeholder to detail the functionalities provided by 
the Collector
class to an |ns3| simulation, and gives examples on how to code them
in a program. 

**Note:** As of ns-3.18, Collectors are still under development and
not yet provided as part of the framework.
